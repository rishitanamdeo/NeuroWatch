import React, { useEffect, useState } from "react";

/**
 * RiskGauge.jsx
 * Circular arc gauge showing risk 0-100. Color shifts green -> red.
 * Animated number counter.
 *
 * Props:
 *  - risk: number (0-100)
 *  - status: "SAFE" | "CAUTION" | "WARNING" | "HIGH RISK" | "EMERGENCY"
 */

const STATUS_COLORS = {
  SAFE: "#39ff88",
  CAUTION: "#ffd93d",
  WARNING: "#ff9f1c",
  "HIGH RISK": "#ff5050",
  EMERGENCY: "#ff1f3d",
};

const SIZE = 200;
const STROKE = 16;
const RADIUS = (SIZE - STROKE) / 2;
const CIRCUMFERENCE = Math.PI * RADIUS; // half circle (arc gauge)

export default function RiskGauge({ risk = 0, status = "SAFE" }) {
  const [displayed, setDisplayed] = useState(0);
  const color = STATUS_COLORS[status] || STATUS_COLORS.SAFE;

  // Animate number counting toward target risk
  useEffect(() => {
    const target = Math.round(risk);
    const step = () => {
      setDisplayed((prev) => {
        if (prev === target) return prev;
        const diff = target - prev;
        const inc = Math.sign(diff) * Math.max(1, Math.round(Math.abs(diff) / 5));
        return prev + inc;
      });
    };
    const id = setInterval(step, 30);
    return () => clearInterval(id);
  }, [risk]);

  const pct = Math.max(0, Math.min(100, displayed)) / 100;
  const dashOffset = CIRCUMFERENCE * (1 - pct);

  return (
    <div className="risk-gauge card">
      <div className="gauge-header">
        <span className="gauge-title">📊 Risk Level</span>
      </div>

      <div className="gauge-wrapper">
        <svg width={SIZE} height={SIZE / 2 + 20} viewBox={`0 0 ${SIZE} ${SIZE / 2 + 20}`}>
          {/* Background arc */}
          <path
            d={`M ${STROKE / 2} ${SIZE / 2} A ${RADIUS} ${RADIUS} 0 0 1 ${SIZE - STROKE / 2} ${SIZE / 2}`}
            fill="none"
            stroke="rgba(255,255,255,0.08)"
            strokeWidth={STROKE}
            strokeLinecap="round"
          />
          {/* Value arc */}
          <path
            d={`M ${STROKE / 2} ${SIZE / 2} A ${RADIUS} ${RADIUS} 0 0 1 ${SIZE - STROKE / 2} ${SIZE / 2}`}
            fill="none"
            stroke={color}
            strokeWidth={STROKE}
            strokeLinecap="round"
            strokeDasharray={CIRCUMFERENCE}
            strokeDashoffset={dashOffset}
            style={{ transition: "stroke-dashoffset 0.4s ease, stroke 0.4s ease" }}
          />
        </svg>

        <div className="gauge-value" style={{ color }}>
          <span className="gauge-number">{displayed}</span>
          <span className="gauge-percent">%</span>
        </div>
      </div>

      <div className="gauge-status" style={{ color, borderColor: color }}>
        {status}
      </div>

      <style>{`
        .risk-gauge {
          color: var(--text-primary);
          font-family: var(--font-ui);
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .gauge-header {
          width: 100%;
          margin-bottom: 6px;
        }
        .gauge-title { font-weight: 600; font-size: 15px; }
        .gauge-wrapper {
          position: relative;
          width: ${SIZE}px;
          margin-top: 6px;
        }
        .gauge-value {
          position: absolute;
          bottom: 4px;
          left: 0;
          right: 0;
          display: flex;
          align-items: baseline;
          justify-content: center;
          font-family: var(--font-mono);
          font-weight: 700;
        }
        .gauge-number { font-size: 40px; }
        .gauge-percent { font-size: 18px; margin-left: 2px; }
        .gauge-status {
          margin-top: 10px;
          font-family: var(--font-mono);
          font-weight: 700;
          font-size: 13px;
          letter-spacing: 1px;
          border: 1px solid;
          border-radius: 999px;
          padding: 4px 16px;
        }
      `}</style>
    </div>
  );
}
