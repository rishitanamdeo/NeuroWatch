# 🎤 NeuroWatch — 2-Minute Demo Script

**Total time: ~2 minutes. Speak naturally, pause briefly between sections.**

---

### [0:00–0:15] Hook & Problem

> "Every year, crowd crushes at large gatherings — like Kumbh Mela, where over 100 million people gather in one place — kill or injure hundreds of people. By the time officials notice a stampede starting, it's often too late. Traditional CCTV systems need constant high-power processing and still react too slowly."

---

### [0:15–0:35] Our Solution — Introduce the Dashboard

*(Open the Dashboard, scenario = Normal)*

> "This is NeuroWatch. Instead of processing full video frames constantly, we use a **neuromorphic, event-driven approach** — inspired by how the human retina and brain work. Our system only 'fires' when something changes — a spike — making it dramatically more efficient and faster to react.
>
> Right now we're in **Normal** mode. The heatmap is calm, the risk gauge reads around 15-20%, and the venue map shows no danger zones."

---

### [0:35–1:00] Trigger Surge Scenario

*(Click "Kumbh Surge")*

> "Now let's simulate a surge near the Food Court. Watch the heatmap — a hotspot forms instantly. Behind the scenes, our **Leaky Integrate-and-Fire neurons** are firing, and an **STDP learning rule** detects that neighboring 'neurons' are firing *together* — a signature of a synchronized crowd surge.
>
> The risk gauge climbs to around 50-65%, the status flips to **WARNING**, and look at the venue map — it automatically highlights **Zone C3** and draws the recommended evacuation route to **Gate 2**. The rescue panel tells responders exactly what to do: increase crowd control, deploy 6 officers, prepare Route B."

---

### [1:00–1:35] Trigger Crush Scenario — Emergency

*(Click "Crush Scenario")*

> "Now the worst case — a crush. Risk spikes to over 90%. Status becomes **EMERGENCY**.
>
> Notice three things happening simultaneously:
> 1. The venue map highlights **Zone C4** in red with a glowing alert, and draws an animated rescue route to the **Emergency Exit, Gate 3**.
> 2. Our system has detected a **possible victim** — a person who isn't moving while everyone around them is — flagged with a confidence score.
> 3. An **emergency announcement banner** appears at the top, and — listen — it's being **read aloud automatically** using text-to-speech, so on-ground announcement systems could broadcast it instantly."

*(Let TTS play for ~3-4 seconds)*

---

### [1:35–1:50] Alert History

*(Click "Alert History" in the nav)*

> "Every event is logged here in real time — timestamped, color-coded by severity, filterable, and exportable for post-incident review."

---

### [1:50–2:00] Closing

> "NeuroWatch combines neuromorphic computing principles with real-time crowd analytics to detect danger *before* it becomes a tragedy — giving responders the critical seconds they need to act. Thank you!"

---

## 🎯 Key Talking Points (if asked questions)

- **"Why neuromorphic?"** — Event-driven processing means the system only computes when something changes, drastically reducing power and compute needs versus constant frame-by-frame video analysis — ideal for low-power edge deployment at large venues.
- **"Is this real AI?"** — Yes: LIF (Leaky Integrate-and-Fire) is a real spiking neuron model, and STDP (Spike-Timing-Dependent Plasticity) is a biologically-inspired unsupervised learning rule used in neuromorphic chips like Intel Loihi.
- **"Scalability?"** — The 10×10 grid maps to real venue zones; in production this would scale to many camera feeds, each running its own lightweight spiking network on edge hardware.
- **"What's next?"** — Real DVS (Dynamic Vision Sensor) camera integration, deployment on neuromorphic chips (Loihi/Akida), multi-camera fusion, and integration with public announcement systems and drone-based officer dispatch.
