import React, { useRef, useEffect } from "react";

/**
 * AlertFeed.jsx
 * Props:
 *  - alerts: Array<{
 *      id: string|number,
 *      timestamp: string,   // e.g. "14:32:08"
 *      risk: number,        // 0-100
 *      zone: string | null,
 *      status: "SAFE"|"CAUTION"|"WARNING"|"HIGH RISK"|"EMERGENCY",
 *      message: string
 *    }>
 *  - maxItems?: number (default 50)
 */

const STATUS_STYLES = {
  SAFE:        { color: "#39ff88", bg: "rgba(57,255,136,0.08)",  border: "rgba(57,255,136,0.3)" },
  CAUTION:     { color: "#ffd93d", bg: "rgba(255,217,61,0.08)",  border: "rgba(255,217,61,0.3)" },
  WARNING:     { color: "#ff9f1c", bg: "rgba(255,159,28,0.1)",   border: "rgba(255,159,28,0.35)" },
  "HIGH RISK": { color: "#ff5050", bg: "rgba(255,80,80,0.1)",    border: "rgba(255,80,80,0.35)" },
  EMERGENCY:   { color: "#ff1f3d", bg: "rgba(255,31,61,0.14)",   border: "rgba(255,31,61,0.5)" },
};

export default function AlertFeed({ alerts = [], maxItems = 50 }) {
  const feedRef = useRef(null);
  const displayed = alerts.slice(0, maxItems);

  useEffect(() => {
    if (feedRef.current) {
      feedRef.current.scrollTop = 0; // newest alert is at top (prepended)
    }
  }, [alerts.length]);

  return (
    <div className="alert-feed">
      <div className="alert-feed-header">
        <span className="alert-feed-title">📡 Live Alert Feed</span>
        <span className="alert-feed-count">{displayed.length} events</span>
      </div>

      <div className="alert-feed-list" ref={feedRef}>
        {displayed.length === 0 && (
          <div className="alert-empty">No alerts yet — system monitoring normally.</div>
        )}

        {displayed.map((alert) => {
          const style = STATUS_STYLES[alert.status] || STATUS_STYLES.SAFE;
          return (
            <div
              key={alert.id}
              className="alert-item"
              style={{ background: style.bg, borderColor: style.border }}
            >
              <div className="alert-row1">
                <span className="alert-time">{alert.timestamp}</span>
                <span className="alert-badge" style={{ color: style.color, borderColor: style.color }}>
                  {alert.status}
                </span>
                {alert.zone && <span className="alert-zone">Zone {alert.zone}</span>}
                <span className="alert-risk" style={{ color: style.color }}>
                  {alert.risk}%
                </span>
              </div>
              <div className="alert-message">{alert.message}</div>
            </div>
          );
        })}
      </div>

      <style>{`
        .alert-feed {
          background: #11151f;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 14px;
          padding: 14px;
          color: #e6edf3;
          font-family: 'Inter', sans-serif;
          display: flex;
          flex-direction: column;
          height: 100%;
        }
        .alert-feed-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
        }
        .alert-feed-title { font-weight: 600; font-size: 15px; }
        .alert-feed-count {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          color: #9fb3c8;
        }
        .alert-feed-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
          overflow-y: auto;
          flex: 1;
          padding-right: 4px;
        }
        .alert-feed-list::-webkit-scrollbar { width: 6px; }
        .alert-feed-list::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,0.1);
          border-radius: 3px;
        }
        .alert-empty {
          color: #6b7d91;
          font-size: 13px;
          text-align: center;
          padding: 24px 0;
        }
        .alert-item {
          border: 1px solid;
          border-radius: 10px;
          padding: 8px 10px;
          animation: fadeIn 0.4s ease-out;
        }
        .alert-row1 {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 4px;
          flex-wrap: wrap;
        }
        .alert-time {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          color: #9fb3c8;
        }
        .alert-badge {
          font-family: 'JetBrains Mono', monospace;
          font-size: 10px;
          font-weight: 700;
          border: 1px solid;
          border-radius: 999px;
          padding: 1px 8px;
          letter-spacing: 0.5px;
        }
        .alert-zone {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          background: rgba(255,255,255,0.06);
          padding: 1px 6px;
          border-radius: 6px;
        }
        .alert-risk {
          font-family: 'JetBrains Mono', monospace;
          font-size: 12px;
          font-weight: 700;
          margin-left: auto;
        }
        .alert-message {
          font-size: 12.5px;
          color: #cfd8e3;
          line-height: 1.4;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-6px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
