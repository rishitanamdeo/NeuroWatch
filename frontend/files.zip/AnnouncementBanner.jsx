import React, { useEffect, useRef } from "react";

/**
 * AnnouncementBanner.jsx
 * Auto-displays when risk > 75 and speaks the announcement via
 * the browser SpeechSynthesis API.
 *
 * Props:
 *  - risk: number (0-100)
 *  - announcement: string
 */
export default function AnnouncementBanner({ risk, announcement }) {
  const lastSpokenRef = useRef("");

  const visible = risk > 75 && announcement;

  useEffect(() => {
    if (!visible) return;
    if (lastSpokenRef.current === announcement) return; // avoid repeating same message
    if (!("speechSynthesis" in window)) return;

    const utter = new SpeechSynthesisUtterance(announcement);
    utter.rate = 0.95;
    utter.pitch = 1;
    utter.volume = 1;

    window.speechSynthesis.cancel(); // stop any prior speech
    window.speechSynthesis.speak(utter);
    lastSpokenRef.current = announcement;
  }, [announcement, visible]);

  if (!visible) return null;

  return (
    <div className="announcement-banner">
      <span className="announcement-banner-icon">📢</span>
      <span className="announcement-banner-text">{announcement}</span>
      <span className="announcement-banner-risk">RISK {risk}%</span>

      <style>{`
        .announcement-banner {
          display: flex;
          align-items: center;
          gap: 12px;
          background: linear-gradient(90deg, rgba(255,31,61,0.18), rgba(255,31,61,0.08));
          border: 1px solid rgba(255,31,61,0.4);
          border-radius: 12px;
          padding: 12px 18px;
          color: #ffe6e6;
          font-family: 'Inter', sans-serif;
          font-size: 14px;
          margin-bottom: 14px;
          animation: bannerPulse 1.5s infinite ease-in-out;
        }
        .announcement-banner-icon { font-size: 20px; }
        .announcement-banner-text { flex: 1; line-height: 1.4; }
        .announcement-banner-risk {
          font-family: 'JetBrains Mono', monospace;
          font-weight: 700;
          font-size: 12px;
          background: rgba(255,31,61,0.25);
          padding: 4px 10px;
          border-radius: 999px;
          white-space: nowrap;
        }
        @keyframes bannerPulse {
          0%, 100% { box-shadow: 0 0 0px rgba(255,31,61,0.4); }
          50% { box-shadow: 0 0 18px rgba(255,31,61,0.5); }
        }
      `}</style>
    </div>
  );
}
